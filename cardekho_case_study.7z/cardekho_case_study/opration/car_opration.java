package com.jspiders.cardekho_case_study.opration;
import java.util.ArrayList;
import java.util.Scanner;

public class car_opration {
 public void addCar() {
	 car c=new car();
	 System.out.println("How many car you want to add");
	 Scanner sc=new Scanner(System.in);
	 int a=sc.nextInt();
     .setCar_id();
	    
	 
	 
 }
}