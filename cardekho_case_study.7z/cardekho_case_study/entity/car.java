package com.jspiders.cardekho_case_study.entity;
import java.util.*;
public class car {
	private int car_id;
    private String name;
    private String model;
    private String brand;
    private String fuel_type;
    private double price;
    
    ArrayList obj=new ArrayList();
	public int getCar_id() {
		return car_id;
	}
	public void setCar_id(int car_id) {
		//this.car_id = car_id;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter car id");
		int i1=sc.nextInt();
		System.out.println("Enter car name");
		String s1=sc.nextLine();
		
		
	}
    
    }
