package com.jspiders.cardekho_case_study.main;
import java.util.Scanner;

import com.jspiders.cardekho_case_study.opration.car_opration;
public class car_dekho_menu {
    
	
  public static void main(String[] args) {
	  
	    System.out.println("=======MENU========");
		System.out.println("1.Add Car Details");
		System.out.println("2.Search Car Details");
		System.out.println("3.Updata Car Details");
		System.out.println("4.Delete Car Details");
		System.out.println("5.Exit");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		car_opration co=new car_opration();
		co.addCar();
	  
  }
}

 